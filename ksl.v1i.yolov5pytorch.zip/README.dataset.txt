# ksl > 2025-05-03 1:17pm
https://universe.roboflow.com/sign-language-y1ocw/ksl-abotx

Provided by a Roboflow user
License: CC BY 4.0

